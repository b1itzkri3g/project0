from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from sqlalchemy import text
import os
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'my_secret_mmk')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../../database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

TELEGRAM_TOKEN = "8140699681:AAFB9JRTfbFstnP4Nqbr2dcXYp8Gh0QqjkA"

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'admin_login'

# Admin model (separate table)
class Admin(UserMixin, db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password_hash = db.Column(db.String(200))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Existing database models
class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.String, primary_key=True)
    username = db.Column(db.String)
    password = db.Column(db.String)
    confirm_button = db.Column(db.String(20))
    def set_password(self,password):
        self.password = password
    def set_userid(self,user_id):
        self.user_id = user_id
    def set_confirm(self):
        self.confirm_button = "no"

class Balance(db.Model):
    __tablename__ = 'balance'
    user_id = db.Column(db.String, primary_key=True)
    amount = db.Column(db.Integer)

class BalancePh(db.Model):
    __tablename__ = 'balance_ph'
    user_id = db.Column(db.String, primary_key=True)
    amount = db.Column(db.Integer)

class DiaPrice(db.Model):
    __tablename__ = 'dia_price'
    package_no = db.Column(db.Integer, primary_key=True)
    diamond = db.Column(db.String)
    price = db.Column(db.Integer)

class DiaPricePh(db.Model):
    __tablename__ = 'dia_price_ph'
    package_no = db.Column(db.Integer, primary_key=True)
    diamond = db.Column(db.String)
    price = db.Column(db.Integer)

class Transaction(db.Model):
    __tablename__ = 'transaction'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String)
    diamond = db.Column(db.Integer)
    price = db.Column(db.Integer)
    t_date = db.Column(db.String)
    status = db.Column(db.String(255))
    main_user = db.Column(db.String(255))
    balance_type = db.Column(db.String(50))  # 'regular' or 'ph'


class Transcation(db.Model):
    __tablename__ = 'transcation'
    user_id = db.Column(db.String, primary_key=True)
    diamond = db.Column(db.Integer)
    price = db.Column(db.Integer)
    t_date = db.Column(db.String, primary_key=True)
    status = db.Column(db.String(255))  # This might not exist in DB
    main_user = db.Column(db.String(255))  # This might not exist in DB

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

def create_initial_admin():
    with app.app_context():
        db.create_all()
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(username='admin')
            admin.set_password('b1itz_linpaing')
            db.session.add(admin)
            db.session.commit()

create_initial_admin()

# Routes
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and admin.check_password(password):
            login_user(admin)
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin credentials', 'danger')
    return render_template('admin_login.html')

@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    users_count = User.query.count()
    transactions_count = Transaction.query.count()
    announcements_count = 0  # You'll need to track this if you want it
    
    return render_template('admin_dashboard.html',
                         users_count=users_count,
                         transactions_count=transactions_count,
                         announcements_count=announcements_count)

# Separate update routes for regular and PH balances
@app.route('/admin/update-regular-balance', methods=['POST'])
@login_required
def update_regular_balance():
    user_id = request.form.get('user_id')
    amount = int(request.form.get('amount'))
    
    balance = Balance.query.filter_by(user_id=user_id).first()
    if balance:
        balance.amount += amount
    else:
        new_balance = Balance(user_id=user_id, amount=amount)
        db.session.add(new_balance)
    
    # Record transaction
    new_transaction = Transaction(
        user_id=user_id,
        diamond=0,
        price=amount,
        t_date=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        status='completed',
        main_user=current_user.username,
        balance_type='regular'  # Add this field to track balance type
    )
    db.session.add(new_transaction)
    db.session.commit()
    flash('Regular balance updated successfully', 'success')
    return redirect(url_for('balance_management'))

@app.route('/admin/update-ph-balance', methods=['POST'])
@login_required
def update_ph_balance():
    user_id = request.form.get('user_id')
    amount = int(request.form.get('amount'))
    
    balance = BalancePh.query.filter_by(user_id=user_id).first()
    if balance:
        balance.amount += amount
    else:
        new_balance = BalancePh(user_id=user_id, amount=amount)
        db.session.add(new_balance)
    
    # Record transaction
    new_transaction = Transaction(
        user_id=user_id,
        diamond=0,
        price=amount,
        t_date=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        status='completed',
        main_user=current_user.username,
        balance_type='ph'  # Add this field to track balance type
    )
    db.session.add(new_transaction)
    db.session.commit()
    flash('PH balance updated successfully', 'success')
    return redirect(url_for('balance_management'))

@app.route('/admin/balances')
@login_required
def balance_management():
    regular = {}
    ph = {}
    
    # Get all users with their balances
    users = User.query.all()
    for user in users:
        # Regular balance
        balance = Balance.query.filter_by(user_id=user.user_id).first()
        regular[user.user_id] = {
            'username': user.username,
            'amount': balance.amount if balance else 0
        }
        
        # PH balance
        ph_balance = BalancePh.query.filter_by(user_id=user.user_id).first()
        ph[user.user_id] = {
            'username': user.username,
            'amount': ph_balance.amount if ph_balance else 0
        }
    
    return render_template('balance_management.html', 
                         balances={'regular': regular, 'ph': ph})

@app.route('/admin/transactions')
@login_required
def transaction_history():
    transactions = db.session.query(
        Transaction,
        User.username
    ).join(User, Transaction.user_id == User.user_id).all()
    
    return render_template('transaction_history.html', transactions=transactions)

@app.route('/admin/user_transactions')
@login_required
def transcation_history():
    page = request.args.get('page', 1, type=int)
    per_page = 20  # Show 20 transactions per page
    offset = (page - 1) * per_page
    
    # Get total count using raw SQL with text()
    total_count_result = db.session.execute(text("SELECT COUNT(*) FROM transcation")).fetchone()
    total_count = total_count_result[0]
    
    # Get paginated data using raw SQL with text()
    query = text("""
        SELECT t.user_id, t.diamond, t.price, t.t_date, u.username
        FROM transcation t
        JOIN users u ON t.user_id = u.user_id
        ORDER BY t.t_date DESC
        LIMIT :limit OFFSET :offset
    """)
    
    results = db.session.execute(
        query, 
        {"limit": per_page, "offset": offset}
    ).fetchall()
    
    # Calculate total pages
    total_pages = (total_count + per_page - 1) // per_page
    
    # Calculate pagination range
    start_page = max(1, page - 2)
    end_page = min(total_pages + 1, page + 3)
    page_range = list(range(start_page, end_page))
    
    return render_template(
        'user_transaction_history.html', 
        transactions=results,
        page=page,
        total_pages=total_pages,
        total_count=total_count,
        page_range=page_range
    )

@app.route('/admin/create', methods=['GET', 'POST'])
@login_required
def create_admin():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if Admin.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('create_admin'))
        
        new_admin = Admin(username=username)
        new_admin.set_password(password)
        db.session.add(new_admin)
        db.session.commit()
        flash('Admin account created', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('create_admin.html')

@app.route('/admin/create_user', methods=['GET', 'POST'])
@login_required
def create_user():
    if request.method == 'POST':
        userid = request.form.get('userid')
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Validate user_id
        if not userid:
            flash('User ID is required', 'danger')
            return redirect(url_for('create_user'))
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('create_user'))
        
        # Create new user
        new_user = User()
        new_user.set_userid(userid)
        new_user.username = username
        new_user.set_password(password)
        new_user.set_confirm()
        
        # Add the new user to the session
        db.session.add(new_user)
        
        # Create initial balance records for the new user
        new_balance = Balance(user_id=userid, amount=0)
        new_balance_ph = BalancePh(user_id=userid, amount=0)
        db.session.add(new_balance)
        db.session.add(new_balance_ph)
        
        # Commit all changes to the database
        db.session.commit()
        
        flash('User account created', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('create_user.html')


@app.route('/admin/announcements', methods=['GET', 'POST'])
@login_required  # Ensure this decorator is defined elsewhere in your code
def announcements():
    if request.method == 'POST':
        # Retrieve form data
        message = request.form.get('message')
        photo = request.files.get('photo')
        document = request.files.get('document')

        try:
            # Validate inputs
            if not any([message, photo, document]):
                flash('Error: At least one of message, photo, or document must be provided.', 'danger')
                return redirect(url_for('announcements'))

            # Fetch all user IDs (chat IDs) from the database
            users = User.query.all()
            chat_ids = [user.user_id for user in users]

            # Send announcements to all users
            for chat_id in chat_ids:
                if message:
                    send_telegram_message(chat_id, message)
                if photo:
                    send_telegram_photo(chat_id, photo)
                if document:
                    send_telegram_document(chat_id, document)

            flash('Announcement sent successfully to all users!', 'success')

        except Exception as e:
            # Log the error and notify the user
            app.logger.error(f"Error sending announcement: {str(e)}")
            flash(f'Error: {str(e)}', 'danger')

        return redirect(url_for('announcements'))

    # Render the announcements page for GET requests
    return render_template('announcements.html')

# Telegram Functions
def send_telegram_message(chat_id, text):
    """
    Sends a text message to the specified Telegram chat.
    """
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    response = requests.post(url, json={'chat_id': chat_id, 'text': text, 'parse_mode': 'HTML'})

    # Check if the request was successful
    if response.status_code != 200:
        raise Exception(f"Failed to send message to chat ID {chat_id}: {response.text}")

def send_telegram_photo(chat_id, photo_file):
    """
    Sends a photo to the specified Telegram chat.
    """
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendPhoto"
    response = requests.post(url, files={'photo': photo_file}, data={'chat_id': chat_id})

    # Check if the request was successful
    if response.status_code != 200:
        raise Exception(f"Failed to send photo to chat ID {chat_id}: {response.text}")

def send_telegram_document(chat_id, doc_file):
    """
    Sends a document to the specified Telegram chat.
    """
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendDocument"
    response = requests.post(url, files={'document': doc_file}, data={'chat_id': chat_id})

    # Check if the request was successful
    if response.status_code != 200:
        raise Exception(f"Failed to send document to chat ID {chat_id}: {response.text}")



if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=50000, debug=True, threaded=True)
